package com.michael.demo.gridview;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

/**
 * This Five Direction Pad is made by the widget of GridView and Button
 * 
 * ����͹���˵����õ���GridView��Button��ʵ�ֵ�
 * 
 * @author MichaelYe
 * @since 2012-9-4
 * */
public class MainActivity extends Activity 
{

	private ViewHolder viewHolder;
	private final static String STR_WORKBANCH = "Greetings";
	private final static String STR_COMPANY = "Conversation";
	private final static String STR_ZHIXINLI = "Numbers";
	private final static String STR_MANAGE = "Time/Date";
	private final static String STR_ARCHIVE = "Places";
	private final static String STR_ADDRESS_BOOK = "Colours";
	private final static String STR_PLACARD = "Family";
	private final static String STR_MY_ARCHIVE = "Body Parts";
	private final static String STR_SET = "Accomodation";
	
	class ViewHolder
	{
		private Button btnLogout;
		private TextView tvAdd;
		private GridView gvGridView;
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        viewHolder = new ViewHolder();
        iniComponent();
        viewHolder.gvGridView.setSelector(R.drawable.main_icon_bg_selector);//����GridView������Item���Ч��
        viewHolder.gvGridView.setAdapter(new GridViewAdapter(stringList));
        viewHolder.gvGridView.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Context context = MainActivity.this;
				Intent intent = null;
				switch(position){
				//1st activity
				case 0:
					intent = new Intent(context, greetings.class);
					startActivity(intent);
					return;
				//2nd activity
				case 1:
					intent = new Intent(context, conversation.class);
					startActivity(intent);
					return;
				//3rd activity
				case 2:
					intent = new Intent(context, numbers.class);
					startActivity(intent);
					return;
				//4th activity
				case 3:
					//FEATURE UNSUPPORTED
					AlertDialog.Builder alertDialogBuilder11 = new AlertDialog.Builder(MainActivity.this);
					//Setting AlertDialog Title
					alertDialogBuilder11.setTitle("Date/Time");
					//Icon of Alert
					alertDialogBuilder11.setIcon(R.drawable.ic_time);
					//Setting AlertDialog Message
					alertDialogBuilder11.setMessage(Html.fromHtml("<b>Sorry, this feature is not supported yet!</b>"));
					alertDialogBuilder11.setCancelable(false);
					alertDialogBuilder11.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							arg0.cancel();
						}
						
					});
					AlertDialog lock1 = alertDialogBuilder11.create();
					lock1.show();
					return;
				//5th activity
				case 4:
					intent = new Intent(context, place.class);
					startActivity(intent);
					return;
				//6th activity
				case 5:
					//FEATURE UNSUPPORTED
					AlertDialog.Builder alertDialogBuilder12 = new AlertDialog.Builder(MainActivity.this);
					//Setting AlertDialog Title
					alertDialogBuilder12.setTitle("Colours");
					//Icon of Alert
					alertDialogBuilder12.setIcon(R.drawable.ic_colours);
					//Setting AlertDialog Message
					alertDialogBuilder12.setMessage(Html.fromHtml("<b>Sorry, this feature is not supported yet!</b>"));
					alertDialogBuilder12.setCancelable(false);
					alertDialogBuilder12.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							arg0.cancel();
						}
						
					});
					AlertDialog lock2 = alertDialogBuilder12.create();
					lock2.show();
					return;
				//7th activity
				case 6:
					intent = new Intent(context, family.class);
					startActivity(intent);
					return;
				//8th activity
				case 7:
					intent = new Intent(context, body.class);
					startActivity(intent);
					return;
				//9th activity
				case 8:
					//FEATURE UNSUPPORTED
					AlertDialog.Builder alertDialogBuilder13 = new AlertDialog.Builder(MainActivity.this);
					//Setting AlertDialog Title
					alertDialogBuilder13.setTitle("Accomodation");
					//Icon of Alert
					alertDialogBuilder13.setIcon(R.drawable.ic_accommodation);
					//Setting AlertDialog Message
					alertDialogBuilder13.setMessage(Html.fromHtml("<b>Sorry, this feature is not supported yet!</b>"));
					alertDialogBuilder13.setCancelable(false);
					alertDialogBuilder13.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							arg0.cancel();
						}
						
					});
					AlertDialog lock3 = alertDialogBuilder13.create();
					lock3.show();
					return;
				}
				Log.e("++++++++++++++++:", ""+position);
				
			}
		});
    }
    
    private List<String> stringList;
    private void iniComponent()
    {
    	viewHolder.btnLogout = (Button)findViewById(R.id.btn_logout);
    	viewHolder.tvAdd = (TextView)findViewById(R.id.tv_add);
    	viewHolder.gvGridView = (GridView)findViewById(R.id.gv_gridview);
    	viewHolder.btnLogout.setOnClickListener(clickListener);
    	viewHolder.tvAdd.setOnClickListener(clickListener);
    	
    	stringList = new ArrayList<String>();
    	stringList.add("Greetings");
    	stringList.add("Conversation");
    	stringList.add("Numbers");
    	stringList.add("Time/Date");
    	stringList.add("Places");
    	stringList.add("Colours");
    	stringList.add("Family");
    	stringList.add("Body Parts");
    	stringList.add("Accomodation");
    }
    
    private class GridViewAdapter extends BaseAdapter
    {
    	List<String> stringList;
    	int textColor;
    	Drawable iconBg;
    	public GridViewAdapter(List<String> stringList)
    	{
    		this.stringList = stringList;
    		textColor = MainActivity.this.getResources().getColor(R.color.main_button_color);//������ɫ
        	iconBg = MainActivity.this.getResources().getDrawable(R.drawable.main_icon_bg_normal);//͸������
    	}
    	
		public int getCount() {
			return this.stringList.size();
		}

		public Object getItem(int position) {
			return null;
		}

		public long getItemId(int position) {
			return position;
		}
		class ViewHolder
		{
			private Button btn;
		}
		
		public View getView(int position, View convertView, ViewGroup parent) {

			ViewHolder viewHolder;
			if(convertView == null)
			{
				//����һ��ͨ�������ļ�����Item������
//				LayoutInflater myInflater = LayoutInflater.from(Act_Main.this);  
//	            convertView = myInflater.inflate(R.layout.gridview_item, null);
//				viewHolder = new ViewHolder();
//				viewHolder.btn = (Button)convertView.findViewById(R.id.button);
//				convertView.setTag(viewHolder);
				
				viewHolder = new ViewHolder();
				viewHolder.btn = new Button(MainActivity.this);
				viewHolder.btn.setClickable(false);
				viewHolder.btn.setFocusable(false);
				convertView = viewHolder.btn;
				convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
			}
			String str = this.stringList.get(position);
			if(str.equals(STR_WORKBANCH))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_greeting),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_WORKBANCH);
				
			}
			if(str.equals(STR_COMPANY))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_general_conversation),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_COMPANY);
			}
			if(str.equals(STR_ZHIXINLI))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.main_icon_myrecord),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_ZHIXINLI);
			}
			if(str.equals(STR_MANAGE))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_time),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_MANAGE);
			}
			if(str.equals(STR_ARCHIVE))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_directions_places),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_ARCHIVE);
			}
			if(str.equals(STR_ADDRESS_BOOK))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_colours),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_ADDRESS_BOOK);
			}
			if(str.equals(STR_PLACARD))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_family),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_PLACARD);
			}
			if(str.equals(STR_MY_ARCHIVE))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_body_parts),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_MY_ARCHIVE);
			}
			if(str.equals(STR_SET))
			{
				viewHolder.btn.setCompoundDrawablesWithIntrinsicBounds(null,MainActivity.this.getResources().getDrawable(R.drawable.ic_accommodation),null,null);
				viewHolder.btn.setBackgroundDrawable(iconBg);
				viewHolder.btn.setTextColor(textColor);
				viewHolder.btn.setText(STR_SET);
//				viewHolder.btn.setOnClickListener(new OnClickListener() {
//					
//					public void onClick(View v) {
//						// TODO Auto-generated method stub
//						Log.e("111111111111111", "");
//					}
//				});
			}
			
			return convertView;
		}
    	
    };
    
    private View.OnClickListener clickListener = new View.OnClickListener() 
    {
		
		public void onClick(View v) 
		{
			switch (v.getId()) 
			{
				case R.id.btn_logout:
					AlertDialog.Builder alertDialogBuilder11 = new AlertDialog.Builder(MainActivity.this);
					//Setting AlertDialog Title
					alertDialogBuilder11.setTitle("About LearnIbibio");
					//Icon of Alert
					alertDialogBuilder11.setIcon(R.drawable.ic_greeting);
					//Setting AlertDialog Message
					alertDialogBuilder11.setMessage(Html.fromHtml("<b>LearnIbibio</b> is an app for learning Ibibio language <br><font color='red'>This app is still underdevelopment.</font><br> developed by Emmanuel &copy; 2020<br>"));
					alertDialogBuilder11.setCancelable(false);
					alertDialogBuilder11.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							finish();
						}
						
					});
					AlertDialog meandle = alertDialogBuilder11.create();
					meandle.show();
					return;
				case R.id.tv_add:
					break;
			}
		}
    };

}