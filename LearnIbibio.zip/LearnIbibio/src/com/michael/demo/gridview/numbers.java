package com.michael.demo.gridview;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.Html;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
public class numbers extends ListActivity {
private TextToSpeech textToSpeech;
private SoundPool soundPool;
String[] naija_city= {
"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen"
,"Fifteen","Sixteen","Seventeen","Eighteen","Nineteen","Twenty","One hundred","One thousand","One million"
};
/** Called when the activity is first created. */
@Override
public void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
//---no need to call this---//setContentView(R.layout.main);
setListAdapter(new ArrayAdapter<String>(this,
android.R.layout.simple_list_item_1, naija_city));
}

@Override
public void onListItemClick(
ListView parent, View v, int position, long id)
{
	Context context = numbers.this;
	soundPool = new SoundPool(20, AudioManager.STREAM_MUSIC, 0);
	switch(position){
	//1st 
	case 0:
		final MediaPlayer mp2 = MediaPlayer.create(context,R.drawable.a);
		mp2.setAudioStreamType(AudioManager.STREAM_MUSIC);
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder.setTitle("Good morning");
		//Icon of Alert
		alertDialogBuilder.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder.setMessage(Html.fromHtml("English: Good morning/Hi <br> Ibibio: Amesiere"));
		alertDialogBuilder.setCancelable(false);
		alertDialogBuilder.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				mp2.start();
			}
		});
		alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nAmesiere";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle = alertDialogBuilder.create();
		meandle.show();
		return;
	case 1:
		AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder2.setTitle("Good night");
		//Icon of Alert
		alertDialogBuilder2.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder2.setMessage(Html.fromHtml("English: Good night/Hi <br> Ibibio: Asiere"));
		alertDialogBuilder2.setCancelable(false);
		alertDialogBuilder2.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
			
			}
		});
		alertDialogBuilder2.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder2.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nAsiere";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle2 = alertDialogBuilder2.create();
		meandle2.show();
		return;
	case 2:
		AlertDialog.Builder alertDialogBuilder3 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder3.setTitle("How are you?");
		//Icon of Alert
		alertDialogBuilder3.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder3.setMessage(Html.fromHtml("English: How are you? <br> Ibibio: Idem mfo?"));
		alertDialogBuilder3.setCancelable(false);
		alertDialogBuilder3.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
			
			}
		});
		alertDialogBuilder3.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder3.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nIdem mfo";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle3 = alertDialogBuilder3.create();
		meandle3.show();
		return;
	case 3:
		AlertDialog.Builder alertDialogBuilder4 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder4.setTitle("I am fine");
		//Icon of Alert
		alertDialogBuilder4.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder4.setMessage(Html.fromHtml("English: I am fine <br> Ibibio: Idem asong"));
		alertDialogBuilder4.setCancelable(false);
		alertDialogBuilder4.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
		
			}
		});
		alertDialogBuilder4.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder4.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nIdem asong";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle4 = alertDialogBuilder4.create();
		meandle4.show();
		return;
	case 4:
		AlertDialog.Builder alertDialogBuilder5 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder5.setTitle("Thank you");
		//Icon of Alert
		alertDialogBuilder5.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder5.setMessage(Html.fromHtml("English: Thank you <br> Ibibio: sosongo"));
		alertDialogBuilder5.setCancelable(false);
		alertDialogBuilder5.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
			
			}
		});
		alertDialogBuilder5.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder5.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nAfon";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle5 = alertDialogBuilder5.create();
		meandle5.show();
		return;
	case 5:
		AlertDialog.Builder alertDialogBuilder6 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder6.setTitle("Welcome");
		//Icon of Alert
		alertDialogBuilder6.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder6.setMessage(Html.fromHtml("English: Welcome <br> Ibibio: Amedi"));
		alertDialogBuilder6.setCancelable(false);
		alertDialogBuilder6.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		alertDialogBuilder6.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder6.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nAmedi";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle6 = alertDialogBuilder6.create();
		meandle6.show();
		return;
	case 6:
		AlertDialog.Builder alertDialogBuilder7 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder7.setTitle("Thank you very much");
		//Icon of Alert
		alertDialogBuilder7.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder7.setMessage(Html.fromHtml("English: Thank you very much <br> Ibibio: sosongo eti eti"));
		alertDialogBuilder7.setCancelable(false);
		alertDialogBuilder7.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
			
			}
		});
		alertDialogBuilder7.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder7.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nsosongo eti eti";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle7 = alertDialogBuilder7.create();
		meandle7.show();
		return;
	case 7:
		AlertDialog.Builder alertDialogBuilder8 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder8.setTitle("Please");
		//Icon of Alert
		alertDialogBuilder8.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder8.setMessage(Html.fromHtml("English: Please <br> Ibibio: mbok"));
		alertDialogBuilder8.setCancelable(false);
		alertDialogBuilder8.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
		
			}
		});
		alertDialogBuilder8.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder8.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nmbok";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle8 = alertDialogBuilder8.create();
		meandle8.show();
		return;
	case 8:
		AlertDialog.Builder alertDialogBuilder9 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder9.setTitle("Come and eat");
		//Icon of Alert
		alertDialogBuilder9.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder9.setMessage(Html.fromHtml("English: Come and eat <br> Ibibio: Di dia mkpo"));
		alertDialogBuilder9.setCancelable(false);
		alertDialogBuilder9.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		alertDialogBuilder9.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder9.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nDi dia mkpo";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle9 = alertDialogBuilder9.create();
		meandle9.show();
		return;
	case 9:
		AlertDialog.Builder alertDialogBuilder10 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder10.setTitle("God bless you");
		//Icon of Alert
		alertDialogBuilder10.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder10.setMessage(Html.fromHtml("English: God bless you <br> Ibibio: Abasi udiong fien"));
		alertDialogBuilder10.setCancelable(false);
		alertDialogBuilder10.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		alertDialogBuilder10.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder10.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nAbasi udiong fien";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle10 = alertDialogBuilder10.create();
		meandle10.show();
		return;
	case 10:
		AlertDialog.Builder alertDialogBuilder11 = new AlertDialog.Builder(numbers.this);
		//Setting AlertDialog Title
		alertDialogBuilder11.setTitle("No problems");
		//Icon of Alert
		alertDialogBuilder11.setIcon(R.drawable.ic_greeting);
		//Setting AlertDialog Message
		alertDialogBuilder11.setMessage(Html.fromHtml("English: No problems <br> Ibibio: Mfina ibagha"));
		alertDialogBuilder11.setCancelable(false);
		alertDialogBuilder11.setPositiveButton("Speak Ibibio", new DialogInterface.OnClickListener() {	
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
			
			}
		});
		alertDialogBuilder11.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				arg0.cancel();
			}
		});
		alertDialogBuilder11.setNeutralButton("Share as", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int id) {
				// TODO Auto-generated method stub
				String ibi1 = "\nMfina Ibagha";
				Intent share1 = new Intent("android.intent.action.SEND");
				share1.setType("text/plain");
				share1.putExtra("android.intent.extra.SUBJECT","Learn Ibibio");
				share1.putExtra("android.intent.extra.TEXT","\n"+ibi1);
				startActivity(Intent.createChooser(share1,"Share Ibibio Using..."));
			}
		});
		AlertDialog meandle11 = alertDialogBuilder11.create();
		meandle11.show();
		return;
	}

Toast.makeText(this,
"You have selected "+ naija_city[position],
Toast.LENGTH_SHORT).show();
}
}
